﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        components = New ComponentModel.Container()
        Label1 = New Label()
        btnLogout = New Button()
        btnTimeinOut = New Button()
        LabelDate = New Label()
        DataGridView1 = New DataGridView()
        txtStudentID = New TextBox()
        Label3 = New Label()
        Timer1 = New Timer(components)
        Timer2 = New Timer(components)
        CType(DataGridView1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.BackColor = SystemColors.ButtonFace
        Label1.Font = New Font("Segoe UI", 30F, FontStyle.Bold, GraphicsUnit.Point)
        Label1.ForeColor = SystemColors.ActiveCaptionText
        Label1.Location = New Point(-8, -11)
        Label1.Name = "Label1"
        Label1.Size = New Size(399, 54)
        Label1.TabIndex = 0
        Label1.Text = "Student Attendance"
        ' 
        ' btnLogout
        ' 
        btnLogout.Font = New Font("Segoe UI", 15F, FontStyle.Bold, GraphicsUnit.Point)
        btnLogout.Location = New Point(637, 396)
        btnLogout.Name = "btnLogout"
        btnLogout.Size = New Size(104, 42)
        btnLogout.TabIndex = 1
        btnLogout.Text = "Logout"
        btnLogout.UseVisualStyleBackColor = True
        ' 
        ' btnTimeinOut
        ' 
        btnTimeinOut.Font = New Font("Segoe UI", 15F, FontStyle.Bold, GraphicsUnit.Point)
        btnTimeinOut.Location = New Point(536, 66)
        btnTimeinOut.Name = "btnTimeinOut"
        btnTimeinOut.Size = New Size(205, 45)
        btnTimeinOut.TabIndex = 2
        btnTimeinOut.Text = "Time In / Time Out"
        btnTimeinOut.UseVisualStyleBackColor = True
        ' 
        ' LabelDate
        ' 
        LabelDate.AutoSize = True
        LabelDate.BackColor = SystemColors.ButtonFace
        LabelDate.Font = New Font("Segoe UI", 15F, FontStyle.Bold, GraphicsUnit.Point)
        LabelDate.ForeColor = SystemColors.ActiveCaptionText
        LabelDate.Location = New Point(597, 15)
        LabelDate.Name = "LabelDate"
        LabelDate.Size = New Size(57, 28)
        LabelDate.TabIndex = 4
        LabelDate.Text = "Date"
        ' 
        ' DataGridView1
        ' 
        DataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridView1.Location = New Point(12, 117)
        DataGridView1.Name = "DataGridView1"
        DataGridView1.RowTemplate.Height = 25
        DataGridView1.Size = New Size(729, 273)
        DataGridView1.TabIndex = 5
        ' 
        ' txtStudentID
        ' 
        txtStudentID.Location = New Point(12, 88)
        txtStudentID.Name = "txtStudentID"
        txtStudentID.Size = New Size(507, 23)
        txtStudentID.TabIndex = 6
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point)
        Label3.Location = New Point(12, 63)
        Label3.Name = "Label3"
        Label3.Size = New Size(167, 19)
        Label3.TabIndex = 7
        Label3.Text = "ENTER STUDENT ID HERE:"
        ' 
        ' Timer1
        ' 
        Timer1.Enabled = True
        ' 
        ' Timer2
        ' 
        Timer2.Enabled = True
        Timer2.Interval = 10000
        ' 
        ' Form2
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = SystemColors.ButtonFace
        ClientSize = New Size(753, 450)
        Controls.Add(Label3)
        Controls.Add(txtStudentID)
        Controls.Add(DataGridView1)
        Controls.Add(LabelDate)
        Controls.Add(btnTimeinOut)
        Controls.Add(btnLogout)
        Controls.Add(Label1)
        ForeColor = SystemColors.ActiveCaptionText
        Name = "Form2"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Form2"
        CType(DataGridView1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents btnLogout As Button
    Friend WithEvents btnTimeinOut As Button
    Friend WithEvents LabelDate As Label
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents txtStudentID As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Timer2 As Timer
End Class
